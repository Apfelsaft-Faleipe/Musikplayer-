﻿namespace Muso_Music_Player
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private Button GetButtonplay()
        {
            return buttonplay;
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent(Button buttonplay)
        {
            progressBar1 = new ProgressBar();
            buttonZurück = new Button();
            buttonPause = new Button();
            buttonWeiter = new Button();
            buttonplay = new Button();
            buttonSuchen = new Button();
            Lautstärkeregler = new TrackBar();
            labelLautstärke = new Label();
            buttonSongHinzufügen = new Button();
            comboBox1 = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)Lautstärkeregler).BeginInit();
            SuspendLayout();
            // 
            // progressBar1
            // 
            progressBar1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            progressBar1.Location = new Point(12, 271);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(608, 17);
            progressBar1.TabIndex = 4;
            // 
            // buttonZurück
            // 
            buttonZurück.Location = new Point(212, 202);
            buttonZurück.Name = "buttonZurück";
            buttonZurück.Size = new Size(94, 56);
            buttonZurück.TabIndex = 6;
            buttonZurück.Text = "<<";
            buttonZurück.UseVisualStyleBackColor = true;
            // 
            // buttonPause
            // 
            buttonPause.Location = new Point(112, 202);
            buttonPause.Name = "buttonPause";
            buttonPause.Size = new Size(94, 56);
            buttonPause.TabIndex = 7;
            buttonPause.Text = "Pause";
            buttonPause.UseVisualStyleBackColor = true;
            // 
            // buttonWeiter
            // 
            buttonWeiter.Location = new Point(312, 202);
            buttonWeiter.Name = "buttonWeiter";
            buttonWeiter.Size = new Size(94, 56);
            buttonWeiter.TabIndex = 8;
            buttonWeiter.Text = ">>";
            buttonWeiter.UseVisualStyleBackColor = true;
            // 
            // buttonplay
            // 
            buttonplay.Location = new Point(12, 202);
            buttonplay.Name = "buttonplay";
            buttonplay.Size = new Size(94, 56);
            buttonplay.TabIndex = 9;
            buttonplay.Text = "Play";
            buttonplay.UseVisualStyleBackColor = true;
            buttonplay.Click +=////buttonplay_Click;
            // 
            // buttonSuchen
            // 
            buttonSuchen.Location = new Point(312, 12);
            buttonSuchen.Name = "buttonSuchen";
            buttonSuchen.Size = new Size(94, 29);
            buttonSuchen.TabIndex = 10;
            buttonSuchen.Text = "Suchen";
            buttonSuchen.UseVisualStyleBackColor = true;
            // 
            // Lautstärkeregler
            // 
            Lautstärkeregler.Location = new Point(412, 202);
            Lautstärkeregler.Name = "Lautstärkeregler";
            Lautstärkeregler.Size = new Size(208, 56);
            Lautstärkeregler.TabIndex = 11;
            // 
            // labelLautstärke
            // 
            labelLautstärke.AutoSize = true;
            labelLautstärke.Location = new Point(477, 238);
            labelLautstärke.Name = "labelLautstärke";
            labelLautstärke.Size = new Size(76, 20);
            labelLautstärke.TabIndex = 12;
            labelLautstärke.Text = "Lautstärke";
            // 
            // buttonSongHinzufügen
            // 
            buttonSongHinzufügen.Location = new Point(470, 12);
            buttonSongHinzufügen.Name = "buttonSongHinzufügen";
            buttonSongHinzufügen.Size = new Size(150, 29);
            buttonSongHinzufügen.TabIndex = 13;
            buttonSongHinzufügen.Text = "Song Hinzufügen +";
            buttonSongHinzufügen.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(12, 12);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(294, 28);
            comboBox1.TabIndex = 14;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(632, 300);
            Controls.Add(comboBox1);
            Controls.Add(buttonSongHinzufügen);
            Controls.Add(labelLautstärke);
            Controls.Add(Lautstärkeregler);
            Controls.Add(buttonSuchen);
            Controls.Add(buttonplay);
            Controls.Add(buttonWeiter);
            Controls.Add(buttonPause);
            Controls.Add(buttonZurück);
            Controls.Add(progressBar1);
            Name = "Form1";
            Text = "Muso Music Player";
            //Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)Lautstärkeregler).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ProgressBar progressBar1;
        private Button buttonZurück;
        private Button buttonPause;
        private Button buttonWeiter;
        private Button buttonplay;
        private Button buttonSuchen;
        private TrackBar Lautstärkeregler;
        private Label labelLautstärke;
        private Button buttonSongHinzufügen;
        private ComboBox comboBox1;
    }
}
