namespace Muso_Music_Player
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(GetButtonplay());
        }

        private void buttonplay_Click(object sender, EventArgs e)
        {

        }
    }
}
