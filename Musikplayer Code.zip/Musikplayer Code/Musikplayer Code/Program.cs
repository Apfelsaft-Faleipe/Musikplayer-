﻿using System;
using System.Drawing;
using System.Media;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MusoMusikPlayer
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new PlayerForm());
        }
    }

    public class PlayerForm : Form
    {
        Button btnOpen, btnPlay, btnStop, btnNext, btnBack, btnVolUp, btnVolDown;
        Label lblStatus;

        SoundPlayer player = new SoundPlayer();
        string[] playlist = new string[0];
        int index = 0;
        int volume = 50;

        public PlayerForm()
        {
            Text = "🎵 Musikplayer (WAV)";
            Size = new Size(520, 260);

            btnOpen = Btn("📂 Öffnen", 20, 20);
            btnBack = Btn("⏮ Back", 20, 70);
            btnPlay = Btn("▶ Play", 120, 70);
            btnStop = Btn("⏹ Stop", 220, 70);
            btnNext = Btn("⏭ Skip", 320, 70);
            btnVolDown = Btn("🔉 -", 120, 120);
            btnVolUp = Btn("🔊 +", 220, 120);

            lblStatus = new Label()
            {
                Left = 20,
                Top = 170,
                Width = 460,
                Text = "Keine Datei geladen"
            };

            Controls.AddRange(new Control[]
            {
                btnOpen, btnBack, btnPlay, btnStop, btnNext,
                btnVolDown, btnVolUp, lblStatus
            });

            btnOpen.Click += OpenFiles;
            btnPlay.Click += (s, e) => Play();
            btnStop.Click += (s, e) => Stop();
            btnNext.Click += (s, e) => Skip();
            btnBack.Click += (s, e) => Back();
            btnVolUp.Click += (s, e) => SetVolume(volume + 10);
            btnVolDown.Click += (s, e) => SetVolume(volume - 10);

            SetVolume(volume);
        }

        Button Btn(string text, int x, int y) =>
            new Button() { Text = text, Left = x, Top = y, Width = 90, Height = 35 };

        void OpenFiles(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "WAV Dateien (*.wav)|*.wav";
                dlg.Multiselect = true;

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    playlist = dlg.FileNames;
                    index = 0;
                    LoadSong();
                }
            }
        }

        void LoadSong()
        {
            if (playlist.Length == 0) return;
            player.SoundLocation = playlist[index];
            lblStatus.Text = $"Geladen: {playlist[index]}";
        }

        void Play()
        {
            if (playlist.Length == 0) return;
            player.Play();
            lblStatus.Text = "🎵 Spielt";
        }

        void Stop()
        {
            player.Stop();
            lblStatus.Text = "⏸ Gestoppt";
        }

        void Skip()
        {
            if (playlist.Length == 0) return;
            index = (index + 1) % playlist.Length;
            LoadSong();
            Play();
        }

        void Back()
        {
            if (playlist.Length == 0) return;
            index = (index - 1 + playlist.Length) % playlist.Length;
            LoadSong();
            Play();
        }

        void SetVolume(int v)
        {
            volume = Math.Max(0, Math.Min(100, v));
            int vol = volume * 65535 / 100;
            waveOutSetVolume(IntPtr.Zero, vol | (vol << 16));
            lblStatus.Text = $"🔊 Lautstärke: {volume}%";
        }

        [DllImport("winmm.dll")]
        static extern int waveOutSetVolume(IntPtr hwo, int dwVolume);
    }
}
